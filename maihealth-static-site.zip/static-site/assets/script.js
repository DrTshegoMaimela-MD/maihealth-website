document.addEventListener('DOMContentLoaded', function() {

  // ─── Navbar scroll effect ───
  const navbar = document.querySelector('.navbar');
  window.addEventListener('scroll', function() {
    if (window.scrollY > 40) navbar.classList.add('scrolled');
    else navbar.classList.remove('scrolled');
  });

  // ─── Mobile nav toggle ───
  window.toggleMobile = function() {
    document.querySelector('.nav-links').classList.toggle('open');
  };

  // ─── Assessment Quiz ───
  const questions = [
    { text: "I can focus deeply on complex tasks without getting distracted", cat: "Focus" },
    { text: "I have enough mental energy for creative problem-solving", cat: "Creativity" },
    { text: "I can make important decisions without feeling overwhelmed", cat: "Decision Making" },
    { text: "I maintain clarity when juggling multiple priorities", cat: "Multitasking" },
    { text: "I feel mentally refreshed at the start of each day", cat: "Recovery" },
  ];

  let answers = [];
  let currentQ = 0;
  const labels = ["", "Rarely", "Sometimes", "Often", "Most of the time", "Always"];

  function renderAssessment() {
    const wrap = document.getElementById('assessment-quiz');
    if (!wrap) return;
    if (answers.length === questions.length) {
      showResult();
      return;
    }
    const q = questions[currentQ];
    const pct = Math.round((currentQ / questions.length) * 100);
    wrap.innerHTML = `
      <div class="assessment-progress">
        <div class="assessment-progress-label">
          <span>Question ${currentQ + 1} of ${questions.length}</span>
          <span>${pct}%</span>
        </div>
        <div class="assessment-progress-bar">
          <div class="assessment-progress-fill" style="width:${pct}%"></div>
        </div>
      </div>
      <div class="assessment-question">
        <span class="assessment-cat">${q.cat}</span>
        <h3>${q.text}</h3>
        <div class="assessment-options">
          ${[1,2,3,4,5].map(s => `
            <button class="assessment-option" onclick="selectAnswer(${s})">
              <span>${s} — ${labels[s]}</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
            </button>
          `).join('')}
        </div>
      </div>
      <div class="assessment-nav">
        <button class="btn-nav-prev" onclick="prevQuestion()" ${currentQ===0?'disabled':''}>Previous</button>
        <button class="btn-nav-next" onclick="nextQuestion()" disabled>Next</button>
      </div>
    `;
    updateNextBtn();
  }

  window.selectAnswer = function(score) {
    answers[currentQ] = score;
    const opts = document.querySelectorAll('.assessment-option');
    opts.forEach((btn, i) => {
      if (i + 1 === score) {
        btn.style.borderColor = 'rgba(91,192,222,0.5)';
        btn.style.background = 'rgba(255,255,255,0.08)';
      } else {
        btn.style.borderColor = '';
        btn.style.background = '';
      }
    });
    updateNextBtn();
    setTimeout(() => {
      if (currentQ < questions.length - 1) {
        currentQ++;
        renderAssessment();
      } else {
        showResult();
      }
    }, 250);
  };

  window.prevQuestion = function() {
    if (currentQ > 0) { currentQ--; renderAssessment(); }
  };

  window.nextQuestion = function() {
    if (currentQ < questions.length - 1) { currentQ++; renderAssessment(); }
    else showResult();
  };

  function updateNextBtn() {
    const btn = document.querySelector('.btn-nav-next');
    if (btn) btn.disabled = answers[currentQ] === undefined;
    if (btn && currentQ === questions.length - 1) btn.textContent = 'See Results';
  }

  function showResult() {
    const total = answers.reduce((s, a) => s + a, 0);
    const pct = Math.round((total / (questions.length * 5)) * 100);
    let status = 'red', label = 'Critical Depletion', color = '#ef4444', advice = 'Your bandwidth is severely depleted. Immediate intervention advised.';
    if (pct >= 70) { status = 'green'; label = 'Healthy Bandwidth'; color = '#5BC0DE'; advice = 'Your mental capacity is in a good place. Focus on maintenance.'; }
    else if (pct >= 45) { status = 'amber'; label = 'Depleted — Action Needed'; color = '#f59e0b'; advice = 'Your cognitive load is elevated. Recovery practices recommended.'; }

    const wrap = document.getElementById('assessment-quiz');
    if (!wrap) return;
    wrap.innerHTML = `
      <div class="glass-card" style="padding:32px;text-align:center">
        <h2 style="font-size:1.75rem;font-weight:800;margin-bottom:8px;color:${color}">${label}</h2>
        <p style="color:#9ca3af;margin-bottom:20px">${advice}</p>
        <div class="result-ring-wrap">
          <svg viewBox="0 0 144 144">
            <circle class="result-ring-track" cx="72" cy="72" r="60"/>
            <circle class="result-ring-fill" id="score-ring" cx="72" cy="72" r="60" stroke-dasharray="377" stroke-dashoffset="377"/>
          </svg>
          <div class="result-ring-text"><span class="num">${pct}%</span></div>
        </div>
        <p style="color:#9ca3af;font-size:0.875rem;margin-bottom:24px">Your cognitive bandwidth score</p>
        <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap">
          <a href="/claritude/" class="gradient-btn-sm">Full Assessment</a>
          <button onclick="restartAssessment()" class="btn-nav-prev" style="padding:10px 20px">Retake</button>
        </div>
      </div>
    `;
    setTimeout(() => {
      const ring = document.getElementById('score-ring');
      if (ring) ring.style.strokeDashoffset = 377 - ((377 * pct) / 100);
    }, 100);
  }

  window.restartAssessment = function() {
    answers = []; currentQ = 0;
    const intro = document.getElementById('assessment-intro');
    const quiz = document.getElementById('assessment-quiz');
    if (intro) intro.style.display = 'block';
    if (quiz) quiz.innerHTML = '';
  };

  window.startAssessment = function() {
    const intro = document.getElementById('assessment-intro');
    if (intro) intro.style.display = 'none';
    renderAssessment();
  };

  // ─── Smooth scroll for anchor links ───
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', function(e) {
      const href = this.getAttribute('href');
      if (href === '#') return;
      const target = document.querySelector(href);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth' });
        document.querySelector('.nav-links')?.classList.remove('open');
      }
    });
  });

});
